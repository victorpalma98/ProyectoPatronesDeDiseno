<?php 
include('connect.php');

$email = $_POST['email'];
$password = $_POST['password'];

$check = mysqli_query($connect,"SELECT * FROM usuarios WHERE correo='$email' AND contrasena='$password'");
$fila= mysqli_fetch_array ($check);
if(mysqli_num_rows($check)>0){
    if ($fila["tipo_user"] == "admin") {
        echo '
        <script>
           alert("Login as admin");
           window.location = "crud/admin.php";
        </script>
       ';  
    }
    elseif ($fila["tipo_user"] == "employee") {
        echo '
        <script>
           alert("Login as employee");
           window.location = "crud/employee.php";
        </script>
       ';  
    }
    elseif ($fila["tipo_user"] == "customer") {
        echo '
        <script>
           alert("Login as customer");
           window.location ="crud/customer.php";
            
        </script>
       '; 
    }
    else {
        echo '
        <script>
           alert("Error en la base de datos. Tipo de usuario incorrecto.");
           window.location ="login.html";
            
        </script>
       '; 
    }
    
}else{
    echo '
        <script>
           alert("Datos erroneos. Intentelo de nuevo.");
           window.location ="login.html";
            
        </script>
       ';
}
?>