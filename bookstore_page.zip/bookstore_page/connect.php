<?php
    $connect = mysqli_connect("localhost","test","123456","patrones_de_diseño")  or die("connection failed!");
    
    
 ?>