<?php
    class buy
    {
        public $servername_buy = "localhost";
        public $username_buy   = "test";
        public $password_buy   = "123456";
        public $database_buy   = "patrones_de_diseño";
        public  $con_buy;
       
        public function __construct()
        {
            $this->con_buy = new mysqli($this->servername_buy, $this->username_buy,$this->password_buy,$this->database_buy);
            if(mysqli_connect_error()) {
             trigger_error("Failed to connect to MySQL: " . mysqli_connect_error());
            }else{
            return $this->con_buy;
            }

        }

        public function buy_book($libro, $comprador, $cantidad, $valorTotal, $metodoPago, $fecha, $num_compra)
        {
            $libro_agregar = $libro;
            $comprador_agregar = $comprador;
            $cantidad_agregar = $cantidad;
            $valorTotal_agregar = $cantidad;
            $metodoPago_agregar = $metodoPago;
            $fecha_agregar = $fecha;
            $num_compra_agregar = $num_compra;
            $query_buy = "INSERT INTO ventas(libro_isbn, comprador, cantidad, valor, metodo, fecha_compra, num_compra) VALUES ('$libro_agregar', '$comprador_agregar', '$cantidad_agregar', '$valorTotal_agregar', '$metodoPago_agregar', '$fecha_agregar', '$num_compra_agregar')";
            $sql_buy = $this->con_buy->query($query_buy);
            if ($sql_buy==true) {
                header("Location:customer.php?msg1=comprar");
            }else{
                echo "libroisbn: " . $libro_agregar . "comprador: " . $comprador_agregar . "cantidad: " . $cantidad .  "valor: " . $valorTotal . "metodo: " .  $metodoPago . "fecha: " . $fecha . "Registration failed try again!" . "num_compra: " . $num_compra;
            }
        }
        
    }
?>