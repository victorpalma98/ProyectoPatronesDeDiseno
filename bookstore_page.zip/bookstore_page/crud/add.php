<?php
  include 'bookclass.php';
  $customerObj = new book();
  if(isset($_POST['submit'])) {
    $customerObj->insertData($_POST);
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Employee Page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
</head>
<body>
<div class="card text-center" style="padding:15px;">
  <h4>Añadir Libro:</h4>
</div><br> 
<div class="container">
    <div class="row">
        <div class="col-md-5 mx-auto">
            <div class="card">
                <div class="card-header bg-dark text-white">
                    <h4>Inserte datos del libro: </h4>
                </div>
                <div class="card-body bg-light">
                  <form action="add.php" method="POST">
                    <div class="form-group">
                      <label for="nombre">Nombre:</label>
                      <input type="text" class="form-control" name="nombre" placeholder="Ingrese nombre" required="">
                    </div>
                    <div class="form-group">
                      <label for="isbn">ISBN:</label>
                      <input type="text" class="form-control" name="isbn" placeholder="Ingrese isbn" required="">
                    </div>
                    <div class="form-group">
                      <label for="valor">Precio:</label>
                      <input type="number" class="form-control" name="valor" placeholder="Ingrese precio" required="">
                    </div>
                    <div class="form-group">
                      <label for="autor">Autor:</label>
                      <input type="text" class="form-control" name="autor" placeholder="Ingrese autor" required="">
                    </div>
                    <div class="form-group">
                      <label for="genero">Genero:</label>
                      <input type="text" class="form-control" name="genero" placeholder="Ingrese genero" required="">
                    </div>
                    <input type="submit" name="submit" class="btn btn-primary" style="float:right;" value="Submit">
                  </form>
                </div>
                </div>
            </div>
        </div>
    </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
