<?php
 
    class Book
    {   
        private $servername = "localhost";
        private $username   = "test";
        private $password   = "123456";
        private $database   = "patrones_de_diseño";
        public  $con;
        // Database Connection 
        public function __construct()
        {
            $this->con = new mysqli($this->servername, $this->username,$this->password,$this->database);
            if(mysqli_connect_error()) {
             trigger_error("Failed to connect to MySQL: " . mysqli_connect_error());
            }else{
            return $this->con;
            }
        }
        
        // Insert book data into books table
        public function insertData($post)
        {
            $nombre = $this->con->real_escape_string($_POST['nombre']);
            $isbn = $this->con->real_escape_string($_POST['isbn']);
            $valor = $this->con->real_escape_string($_POST['valor']);
            $autor = $this->con->real_escape_string($_POST['autor']);
            $genero = $this->con->real_escape_string($_POST['genero']);
            $query="INSERT INTO libro(nombre, isbn, valor, autor, genero) VALUES('$nombre','$isbn','$valor', '$autor', '$genero')";
            $sql = $this->con->query($query);
            if ($sql==true) {
                header("Location:employee.php?msg1=insert");
            }else{
                echo "Registration failed try again!";
            }
        }
        
        public function displayData()
        {
            $query = "SELECT * FROM libro";
            $result = $this->con->query($query);
        if ($result->num_rows > 0) {
            $data = array();
            while ($row = $result->fetch_assoc()) {
                   $data[] = $row;
            }
             return $data;
            }else{
             echo "No found records";
            }
        }

        
        public function deleteRecord($id)
        {
            $query = "DELETE FROM libro WHERE isbn = '$id'";
            $sql = $this->con->query($query);
        if ($sql==true) {
            header("Location:admin.php?msg3=delete");
        }else{
            echo "Record does not delete try again";
            }
        }

        public function comprarLibro($id)
        {
            include 'buy.php';
            $comprador = ''; 
            $cantidad = '';
            $valorTotal = '';
            $metodoPago = '';
            $fecha = '';
            $num_compra = '';
            $compra = new buy ();
            $compra->buy_book($id, $comprador, $cantidad, $valorTotal, $metodoPago, $fecha, $num_compra);
            
        }

        
    }
?>