<?php 
include("connect.php");

$fullname = $_POST['fullname'];
$email = $_POST['email'];
$password = $_POST['password'];
$genero = $_POST['genero'];
$birthdate = $_POST['birthdate'];
$tipoUsuario = "customer";

$moveToDatabase = mysqli_query($connect,"INSERT INTO usuarios(nombre, fecha_nacimiento, genero, correo, contrasena, tipo_user)VALUES('$fullname', '$birthdate', '$genero', '$email','$password', '$tipoUsuario')");

if($moveToDatabase){
    echo '
        <script>
           alert("¡Registro exitoso!");
           window.location = "login.html";
        </script>
       ';

}else{
    echo '
        <script>
           alert("Registro fallido :(");
           window.location ="index.html";
        </script>
       ';

}
?>